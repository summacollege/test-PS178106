@extends('layouts.app')

@section('content')
@include('layouts.alerts')

<p>add student</p>

@endsection
