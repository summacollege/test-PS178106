@extends('layouts.app')

@section('content')
@include('layouts.alerts')

<p>Contact Page</p>

@endsection
